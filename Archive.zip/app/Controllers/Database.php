<?php

namespace App\Controllers;
use mysqli;
use App\Config;

class Database extends Controller
{
	public $user = 'root';
	public $connection;

		private $db = [
			'host' => 'localhost',
			'username' => 'user@obs',
			'password' => '$dnhzi37_b&$77bn',
			'database' => 'obs'

	];


	public function __construct(){
		$this->connect();
	}
	public function connect(){


		// open connection and select database
		$this->connection = new mysqli($this->db['host'], $this->db['username'], $this->db['password'], $this->db['database']);

				// Check connection
		if ($this->connection->connect_errno) {
		   echo "Failed to connect to MySQL: (" . $this->connection->connect_errno . ") " . $this->connection->connect_error;
		} 
		
	}

	public function disconnect(){
		//close any open connection
		if(isset($this->connection)){
			$this->connection->close();
			//unset($this->connection->close());
		}

			
	}


	//perform database queries
	// public function select($sql=""){
	
	// 	/* Prepared statement, stage 1: prepare */
	// 	if (!($stmt = $this->connection->prepare("SELECT INTO test (name) VALUES (?)"))) {
	// 	    echo "Prepare failed: (" . $this->connection->errno . ") " . $this->connection->error;
	// 	}

	// 	/* Prepared statement, stage 2: bind and execute */
	// 	$name = "Kofi'";
	// 	if (!$stmt->bind_param("s", $name)) {
	// 	    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
	// 	}

	// 	if (!$exec = $stmt->execute()) {
	// 	    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
	// 	}

	// 	var_dump($exec);

	// 	// if (!($res = $stmt->get_result())) {
 //  //   	echo "Getting result set failed: (" . $stmt->errno . ") " . $stmt->error;
	// 	// }

	// 	// var_dump($res->fetch_all());

	// }


		//perform database queries
	public function select($sql="", $format=""){
	
		

			if (!$result = $this->connection->query($sql)) {
			    die ("Error: " . $sql . "<br>" . mysqli_error($this->connection));
		}


	  /* determine number of rows result set */

    	if ($result->num_rows > 0){

		while ( $row = $result->fetch_object() ) {
				$results[] = $row;
			}
			
			return $results;
			}
			return false;
	}


		//perform database queries
	public function query($sql=""){
	
		if ($this->connection->query($sql) !== TRUE) {
			    die ("Error: " . $sql . "<br>" . $this->connection->error);
		}
		return true;
	}




	//prepare the user input against mysqli injections
	public function mysql_prep($data){
	return	mysqli_real_escape_string($this->connection, $data);
	}

	



}