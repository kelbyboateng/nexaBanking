<?php

namespace App\Controllers;
use App\Controllers\Database;


class Email extends Controller
{

	public function send($from, $to, $msg){

	}
}