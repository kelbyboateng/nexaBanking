<?php

namespace App\Controllers;
use App\Controllers\Database;


class Hash extends Controller
{

	public function encrypt ($string){
		return  hash('sha256', $string);
	}
}