<?php

namespace App\Controllers;
use App\Controllers\Database;
use App\Controllers\Email;
use App\Controllers\Session;
use App\Controllers\Utility;
use App\Controllers\User;

class Transaction extends Controller
{

	public function getUserTransactions($id){
		$user = new User;
		$transactions = $user->allTransactions($id);
		var_dump($transactions);
	}

}