<?php

namespace App\Controllers;
use App\Controllers\Database;


class Session extends Controller
{


	public function set ($key="", $value=""){
		$_SESSION[$key] = $value;
	}

	public function has ($key=""){
		if (isset($_SESSION[$key])){
			return $_SESSION[$key];
		}
		return false;
	}

	public function clear ($key){
		if (isset($_SESSION[$key])){
			unset($_SESSION[$key]);
			return true;
		}
		return false;
	}


		public function flush (){
		session_unset();
		 session_destroy();
		 return true;
	}
	
}