<?php

namespace App\Controllers;

class Utility extends Controller
{

	public function sanitize_for_html($data){
		return filter_var($data, 7);
	}


// 	filter_var(Array
// (
//     [0] => int
//     [1] => boolean
//     [2] => float
//     [3] => validate_regexp
//     [4] => validate_url
//     [5] => validate_email
//     [6] => validate_ip
//     [7] => string
//     [8] => stripped
//     [9] => encoded
//     [10] => special_chars
//     [11] => unsafe_raw
//     [12] => email
//     [13] => url
//     [14] => number_int
//     [15] => number_float
//     [16] => magic_quotes
//     [17] => callback
// ))
}