<?php

namespace App\Controllers;
use App\Controllers\Database;
use App\Controllers\Email;
use App\Controllers\Session;
use App\Controllers\Utility;

class User extends Controller
{
//this class handles all the user method abstractions

	//this method create a new user and it is invoked from the register page
	public function create_user(array $payload){
		$db = new Database;
		if(!empty($payload)){
		
			$sql = "INSERT INTO users(first_name, last_name, email, password, created_at) VALUES 
			('$payload[first_name]','$payload[last_name]','$payload[email]','$payload[password]',now())";
			
		if ($db->query($sql)){
			return $db->connection->insert_id;
		}

		}

		return false;
	}

	//this method create a updates a user's details and it is invoked from the account update page
		public function update_user(array $payload){
		$db = new Database;
		if(!empty($payload)){
			$sql = "UPDATE users SET first_name = '$payload[first_name]', last_name = '$payload[last_name]', password = '$payload[password]', updated_at = NOW()   WHERE id = '$payload[user_id]'";
		
		
			
		if ($db->query($sql)){

			return true;
		}

		}

		return false;
	}



	//this method create a new user registration email exists  and it is invoked from the register page
	public function check_email_exists ($email){
		$db = new Database;
		$sql = "SELECT id FROM users WHERE email = '$email' ";
		if ($db->select($sql)){
			return true;
		}
		
		return false;

	}


//this method attempts a login request and it is invoked from the login page
	public function attempt_login(array $payload){

		$db = new Database;
		if(!empty($payload)){
		
			$sql = "SELECT * FROM users WHERE email = '$payload[email]' AND PASSWORD = '$payload[password]' LIMIT 1";
			
		if ($result = $db->select($sql)){
			//a user has been found so let's log the user in 
			$session = new Session;
			$session->set('user', $result[0]->id);
			// return $db->connection->insert_id;
			return true;
		}
		else{
			
		return false;
		}

		}

		return false;
	}

	//this method logs the user out and it is  invoked from the logout page
		public function logout(){

			$session = new Session;
			$session->flush();
			return true;

	}

	//this method authenticates the user before accessing a password protected page 
	public function authenticate(){
		//authentication middleware for all the protected pages
		$session = new Session;
		$user_id = $session->has('user');
		if(!$user_id){
			return false;
		}
		return $user_id;

	}

		//this method gets all the details of the user from the database via his ID
		public function detailsById($id){
		//authentication middleware for all the protected pages
		$db = new Database;
		$sql = "SELECT * FROM users WHERE id = '$id'  LIMIT 1";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}

//this method returns all the user's transactional details by his id
		public function userTransactions($id){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "SELECT * FROM transactions WHERE sender_id = '$id'  OR recepient_id = '$id' ORDER BY transactions.id DESC";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}

	//this method returns all the users transactional details for the admin to see
		public function allTransactions(){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "SELECT * FROM transactions  ORDER BY transactions.id DESC";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}

		//this method gets a particular atm card details by the id
		public function getAtmCard($id){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "SELECT * FROM atm_cards  WHERE user_id = '$id' ORDER BY id DESC LIMIT 1";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}

//this method gets a activates an atm card details by the id
	public function activateAtmCard($id){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "UPDATE atm_cards SET status = 'active', issued_at = NOW(), expires_at = NOW() + INTERVAL 2 YEAR WHERE id = '$id' LIMIT 1";

		if (!$result = $db->query($sql)){
			return false;
		}
		
		return $result;

	
	}


		//this method gets a particular atm card details by the id
		public function getThisAtmCard($id){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "SELECT * FROM atm_cards  WHERE id = '$id' ORDER BY id DESC LIMIT 1";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}

		//this method gets a particular all atm card details 
		public function getAllAtmCards(){
		//authentication middleware for all the protected pages
		$db = new Database;
		// $sql = "SELECT * FROM transactions WHERE user_id = '$id' ORDER BY id DESC";
		

		// $sql = "SELECT transactions.id, users.first_name, users.last_name,transactions.created_at, transactions.type,transactions.recipient_id,transactions.amount,transactions.balance, FROM transactions INNER JOIN users ON transactions.user_id=users.id ORDER BY transactions.id DESC";

		$sql = "SELECT atm_cards.id, users.first_name, users.last_name, atm_cards.card_number, atm_cards.status, atm_cards.issued_at, atm_cards.created_at, atm_cards.expires_at FROM atm_cards, users WHERE user_id=users.id  ORDER BY atm_cards.id DESC ";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	
	}




	//this method confirms if the recepient of a transfer exists before a transfer is done
	public function confirm_recepient_exists($id){

			//authentication middleware for all the protected pages
		$db = new Database;
		$sql = "SELECT * FROM users WHERE id = '$id'  LIMIT 1";

		if (!$result = $db->select($sql)){
			return false;
		}
		
		return $result;

	}	


	//this method creates a new atm card detail

	public function new_atm_card_request($id){
		$db = new Database;
		$ut = new Utility;
		$card_number = $ut->randomNDigitNumber(16);
	
		if($id){
		
		$sql = "INSERT INTO atm_cards(user_id, card_number, created_at) VALUES 
			('$id','$card_number',NOW())";

			
		if ($db->query($sql)){
			return $db->connection->insert_id;
		}

		}

		return false;
	}

	//this method generates an atm card renewal
	public function atm_card_renewal($id){
		$db = new Database;
		$ut = new Utility;
		$card_number = $ut->randomNDigitNumber(16);
	
		if($id){
		
		$sql = "INSERT INTO atm_cards(user_id, card_number, created_at) VALUES 
			('$id','$card_number',NOW())";

			
		if ($db->query($sql)){
			return $db->connection->insert_id;
		}

		}

		return false;
	}




}