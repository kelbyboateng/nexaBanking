<?php

namespace App\Controllers;

class Utility extends Controller
{

// Sanitize for HTML output 
public  function h($string) {
	return htmlspecialchars($string);
}

// Sanitize for JavaScript output
public  function j($string) {
	return json_encode($string);
}

// Sanitize for use in a URL
public  function u($string) {
	return urlencode($string);
}


// GET requests should not make changes
// Only POST requests should make changes

public function request_is_get() {
	return $_SERVER['REQUEST_METHOD'] === 'GET';
}

public function request_is_post() {
	return $_SERVER['REQUEST_METHOD'] === 'POST';
}


// Must call session_start() before this loads

// Generate a token for use with CSRF protection.
// Does not store the token.
public function csrf_token() {
	return md5(uniqid(rand(), TRUE));
}

// Generate and store CSRF token in user session.
// Requires session to have been started already.
public function create_csrf_token() {
	$token = $this->csrf_token();
  $_SESSION['csrf_token'] = $token;
 	$_SESSION['csrf_token_time'] = time();
	return $token;
}

// Destroys a token by removing it from the session.
public function destroy_csrf_token() {
  $_SESSION['csrf_token'] = null;
 	$_SESSION['csrf_token_time'] = null;
	return true;
}

// Return an HTML tag including the CSRF token 
// for use in a form.
// Usage: echo csrf_token_tag();
public function csrf_token_tag() {
	$token = $this->create_csrf_token();
	return "<input type=\"hidden\" name=\"csrf_token\" value=\"".$token."\">";
}

// Returns true if user-submitted POST token is
// identical to the previously stored SESSION token.
// Returns false otherwise.
public function csrf_token_is_valid() {
	if(isset($_POST['csrf_token'])) {
		$user_token = $_POST['csrf_token'];
		$stored_token = $_SESSION['csrf_token'];
		return $user_token === $stored_token;
	} else {
		return false;
	}
}

// You can simply check the token validity and 
// handle the failure yourself, or you can use 
// this "stop-everything-on-failure" public function. 
public function die_on_csrf_token_failure() {
	if(!$this->csrf_token_is_valid()) {
		die("CSRF token validation failed.");
	}
}

// Optional check to see if token is also recent
public function csrf_token_is_recent() {
	// $max_elapsed = 60 * 60 * 24; // 1 day
	// $max_elapsed = 60 * 60 * 24; // 1 day
	$max_elapsed = 60 * 60 * 1; // 1 hour
	if(isset($_SESSION['csrf_token_time'])) {
		$stored_time = $_SESSION['csrf_token_time'];
		return ($stored_time + $max_elapsed) >= time();
	} else {
		// Remove expired token
		$this->destroy_csrf_token();
		return false;
	}
}




// Optional check to see if token is also recent
public function valid_csrf() {
	if(!$this->csrf_token_is_valid()) {
		$this->destroy_csrf_token();
		return false;
	}

	if(!$this->csrf_token_is_recent()) {
			$this->destroy_csrf_token();
		return false;
	}
	$this->destroy_csrf_token();
	return true;


}



// Use with request_is_post() to block posting from off-site forms
public function request_is_same_domain() {
	if(!isset($_SERVER['HTTP_REFERER'])) {
		// No refererer sent, so can't be same domain
		return false;
	} else {
		$referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
		$server_host = $_SERVER['HTTP_HOST'];

		//Uncomment for debugging
		// echo 'Request from: ' . $referer_host . "<br />";
		// echo 'Request to: ' . $server_host . "<br />";

		return ($referer_host == $server_host) ? true : false;
	}
}


public function redirectTo($page=""){
	return header('Location: '.$page);
	exit();
}

public function redirect_with_errors($page="", array $errors){

		  $_SESSION['page_errors'] = $errors;
		return header('Location: '.$page);
		exit();
}


public function redirect_with_success($page="", $msg){

		  $_SESSION['success'] = $msg;
		return header('Location: '.$page);
		
}


function randomNDigitNumber($digits)
{
  $returnString = mt_rand(1, 9);
  while (strlen($returnString) < $digits) {
    $returnString .= mt_rand(0, 9);
  }
  return $returnString;
}



}