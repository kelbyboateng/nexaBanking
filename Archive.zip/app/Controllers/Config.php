<?php

namespace App\Controllers;

class Config extends Controller
{

	
}