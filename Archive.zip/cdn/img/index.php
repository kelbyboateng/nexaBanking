<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <title>Corporate 1</title>

    <!-- Bootstrap Core CSS file. Portia pls. try to study the Boostrap tutorial at w3schools.com-->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="css/custom.css" rel="stylesheet">

</head>

<body>
 <!-- classes are used in css and Bootsrap to style a collection of html elements-->
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-equalizer"></span> 
               
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">Home</a>
                    </li>
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Products</a>
                    </li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Services <span class="caret"></span></a>
						<ul class="dropdown-menu" aria-labelledby="about-us">
							<li><a href="#">Engage</a></li>
							<li><a href="#">Pontificate</a></li>
							<li><a href="#">Synergize</a></li>
						</ul>
					</li>
                </ul>

				<!-- Search -->
				<form class="navbar-form navbar-right" role="search">
					<div class="form-group">
						<input type="text" class="form-control">
					</div>
					<button type="submit" class="btn btn-default">Search</button>
				</form>

            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<div class="jumbotron feature">
		<div class="container">
			<h1><span class="glyphicon glyphicon-equalizer"></span> Porshkuma Online Banking System</h1>
			<p>TOO BUSY TO BE IN LINE, JUST A CLICK YOU'LL BE ON LINE.</p>
			
				<div>
					<div>
						<h3><a class="btn btn-default" href="signup.php"><span class="glyphicon glyphicon-log-in"></span>&nbsp;&nbsp;Sign In</a></h3>
						
					</div>
				</div>
				<!-- /.row -->	
			
		
		</div>
	</div>

    <!-- Content -->
    <div class="container">

        <!-- Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                </h1>
                </div>
        </div>
        <!-- /.row -->

        <!-- Feature Row -->
        <div class="row">
            <article class="col-md-4 article-intro">
			 <h3>
                    <a href="accountCreationForm.php">Create an Account With Us</a>
                </h3>
                <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.</p>
            
                <a href="#">
                    <img class="img-responsive img-rounded" src="img.jpg" alt="">
                </a>
                </article>
            <article class="col-md-4 article-intro">
			<h3>
                    <a href="#">Transfer and Receive Funds</a>
                </h3>
                <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.</p>
            
                <a href="#">
                    <img class="img-responsive img-rounded" src="images.jpg" alt="">
                </a>
                  </article>

            <article class="col-md-4 article-intro">
			<h3>
                    <a href="#">Apply for an ATM Card</a>
                </h3>
                <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.</p>
            
                <a href="#">
                    <img class="img-responsive img-rounded" src="img2.jpg" alt="">
                </a>
                  </article>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
	
	<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-open"></span> Open a Bank Account</h3>
						<p>With our Online Banking System, you can complete the bank account creation process from start to finish without ever leaving your home.
						The application form can take less than 10 minutes to fill out. All you have to do is input a few details and send out photocopies of
						whatever form of identification the system requires. It'll still take a few days or weeks before your account is ready, but that's to be expected regardless.</p>
						<p><a class="btn btn-default" href="#">Open an Account Now!</a></p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-transfer"></span>&nbsp;Efficiently Transfer Money</h3>
						<p>Transfer money online with the same convenience of checking your email or surfing the web. Our system makes it possible to send money online 24/7, from the comfort of your own home with our fast, convenient, and safe online money transfer option. </p>
						<p><a class="btn btn-default" href="#">Transfer Now!</a></p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-credit-card"></span> Request an ATM Card</h3>
						<p>You can apply for our new ATM Debit card Online without visiting the Branch, if you have an Internet Banking Account with us.</p>
						<p><a class="btn btn-default" href="#">Request Now!</a></p>
					</div>

				</div>
				<!-- /.row -->	
			</div>
        </div>
        
        <div class="small-print">
        	<div class="container">
        		<p><a href="#">Terms &amp; Conditions</a> | <a href="#">Privacy Policy</a> | <a href="#">Contact</a></p>
        		<p>Copyright &copy; Portia.com 2017 </p>
        	</div>
        </div>
	</footer>

	
    <!-- jQuery -->
    <script src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="js/holder.min.js"></script>
	
</body>

</html>
