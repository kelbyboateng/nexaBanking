<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3 class="header-light"><span class="glyphicon glyphicon-open"></span> Open a Bank Account</h3>
						<p>With our Online Banking System, you can complete the bank account creation process from start to finish without ever leaving your home.
						The application form can take less than 10 minutes to fill out. All you have to do is input a few details and send out photocopies of
						whatever form of identification the system requires. It'll still take a few days or weeks before your account is ready, but that's to be expected regardless.</p>
						<p><a class="btn btn-default" href="register.php">Open an Account Now!</a></p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3 class="header-light"><span class="glyphicon glyphicon-transfer"></span>&nbsp;Efficiently Transfer Money</h3>
						<p>Transfer money online with the same convenience of checking your email or surfing the web. Our system makes it possible to send money online 24/7, from the comfort of your own home with our fast, convenient, and safe online money transfer option. </p>
						<p><a class="btn btn-default" href="transfer.php">Transfer Now!</a></p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3 class="header-light"><span class="glyphicon glyphicon-credit-card"></span> Request an ATM Card</h3>
						<p>You can apply for our new ATM Debit card Online without visiting the Branch, if you have an Internet Banking Account with us.</p>
						<p><a class="btn btn-default" href="#">Request Now!</a></p>
					</div>

				</div>
				<!-- /.row -->	
			</div>
        </div>
        
        <div class="small-print">
        	<div class="container">
        		<p><a href="#">Terms &amp; Conditions</a> | <a href="#">Privacy Policy</a> | <a href="#">Contact</a></p>
        		<p>Copyright &copy; Portia.com 2017 </p>
        	</div>
        </div>
	</footer>

	

  <script type="text/javascript" src="cdn/lib/jquery.min.js"></script>
  <script type="text/javascript" src="cdn/lib/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="cdn/js/ob.js"></script>

  </body>

</html>