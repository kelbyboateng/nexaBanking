<?php
// make a random id
// $_SESSION["token"] = md5(uniqid(mt_rand(), true));
// echo '<a href="process.php?action=logout&csrf=' . $_SESSION["token"] . '">Logout</a></p>';



 // if (isset($_GET["csrf"]) && $_GET["csrf"] == $_SESSION["token"]) {
 //        $_SESSION = array();
 //        session_destroy();
 //    }


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="cdn/lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="cdn/lib/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" type="text/css" href="cdn/css/ob.css">

    <link rel="icon" type="image/png" href="cdn/img/favicon.png">
    <title>Welcome to Online Banking</title>


  </head>

  <body>
 

 