
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="cdn/lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="cdn/lib/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" type="text/css" href="cdn/css/ob.css">

    <link rel="icon" type="image/png" href="cdn/img/favicon.png">
    <title>Welcome - <?php echo $auth_user[0]->first_name . ' ' . $auth_user[0]->last_name;?> </title>



  </head>

  <body>
 
<div class="container-fluid header">
    <div class="container">
      <div class="row">
        <div class="col-md-3">  <img src="cdn/img/ob_logo.png" class="logo"></div>
        <div class="col-md-2"></div>
        
        <div class="col-md-5 account-details">
        <span class="account-balance"><i class="icon-lock"></i> Balance: Gh&cent; <?php echo $auth_user[0]->balance;?> </span> 
        <span  class="account-number"> <i class="icon-user-follow"></i>  Account #: <?php echo $auth_user[0]->id;?></span>
         </div>

      </div>
    </div>
  </div>

<div class="container">
  
  <div class="row">
    <div class="col-md-2 tool-box">
    <nav id="tools-nav">
      <ul>
        <li id="dashboard"> <a href="dashboard.php"> <i class="icon icon-clock"></i> Transactions</a></li>
         <li id="transfer"><a href="transfer.php"> <i class="icon icon-login"></i> Transfer Money</a></li>
          <li id="utility"><a href="utility.php"><i class="icon icon-calendar"></i> Pay Utility Bills</a></li>
            <li id="atm"><a href="atm-cards.php"><i class="icon icon-wallet"></i> My ATM Card</a></li>

            <?php
            if($auth_user[0]->role == 'admin'){
              echo " <li id='atm-requests'><a href='atm-card-requests.php'><i class='icon icon-wallet'></i> All ATM Cards</a></li>";
            }

            ?>
          
           <li id="account"><a href="account.php"><i class="icon icon-user"></i> Account</a></li>
            <li><a href="logout.php"><i class="icon icon-power"></i> Logout</a></li>

      </ul>
    </nav>
  </div>




