</div>
 

  <script type="text/javascript" src="cdn/lib/jquery.min.js"></script>
  <script type="text/javascript" src="cdn/lib/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="cdn/js/ob.js"></script>
 
  <script type="text/javascript">
  var this_link = 	$('span.link-activate').attr('id');
 
  $('nav#tools-nav > ul > li#'+this_link).addClass('active');
 
  </script>
  </body>

</html>